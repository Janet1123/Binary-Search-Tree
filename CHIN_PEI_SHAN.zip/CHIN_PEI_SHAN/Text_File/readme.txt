Group Member 1:

Name: Chin Pei Shan
Student ID: 21ACB06723
Course: IA
Practical Session: Thusday (10am-12pm)
Practical Group: P24
Tutor: Lai Siew Cheng