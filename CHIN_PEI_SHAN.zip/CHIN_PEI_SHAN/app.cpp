//REFERENCES
//[1] Text and reference books for UCCD1024

#include	<iostream>
#include	<fstream>
#include	<cstdlib>
#include	<cstdio>
#include	<ctime>
#include	"BST.h"
#include    "Student.h"

using namespace std;

bool readFile(const char *, BST *);
int menu();

int main() 
{
	BST t1, t2;
	int selection = -1;
	int choice = -1; //whether want to return to menu page
	bool back = false;
	int order, source;
	bool printed;
	Student stu;
	do {
		selection = menu();

		switch (selection)
		{
		case 1:
			system("cls");
			readFile("student2.txt", &t1);
			break;

		case 2:
			t1.deepestNodes();
			break;
		case 3:
			cout << "Do you want to arrange the result(s) according to student ID into (1 = ascending order || 2 = descending order)? : ";
			cin >> order;
			cout << "Do you want to print the result(s) on (1 = screen || 2 = file)? : ";
			cin >> source;
			printed = t1.display(order, source);
			if (!printed)
			{
				cout << "Printed Unsuccessfully!" << endl;
			}
			else
			{
				cout << "\n\nAll result(s) have been printed successfully!\n" << endl;
			}
			break;
		case 4:
			cout << "Enter a student ID to clone subtree: ";
			cin >> stu.id;

			if (!t2.CloneSubtree(t1, stu))
			{
				cout << "\nCannot clone subtree\n\n";
			}
			else
			{
				cout << "\n--------------------------------------------------------------------------------------------\n";
				cout << "                                   Result of original tree                               ";
				cout << "\n--------------------------------------------------------------------------------------------\n";
				t1.preOrderPrint();

				cout << "\n\n--------------------------------------------------------------------------------------------\n";
				cout << "                                   Result of cloned subtree                               ";
				cout << "\n--------------------------------------------------------------------------------------------\n";
				t2.preOrderPrint();
				cout << "\n---------------------------------- printed successfully! ----------------------------------\n";
			}
			break;

		case 5:
			bool LevelPrinted;
			LevelPrinted = t1.printLevelNodes();
			if (!LevelPrinted)
			{
				cout << "Print level node(s) not successful!\n\n";
			}
			break;

		case 6:
			t1.printPath();
			break;

		case 7:
			//system("pause");
			cout << "Thank you for using this system! You will exit now..." << endl << endl;
			return 0;
		}

		cout << "\nDo you want return to menu page? (1 = Yes || 2 = No, exit): ";
		cin >> choice;
		system("cls");

		if (choice == 1)
		{
			back = true;
		}
		else if (choice == 2)
		{
			back = false;
			cout << "Thank you for using this system! You will exit now..." << endl << endl;
		}
		else
		{
			cout << "You can only enter '1' and '2'." << endl;
		}
	} while (back);
	system("pause");
	return 0;
}

void checkDuplicate(BTNode* cur, int Id, bool& duplicate)
{
	if (cur == NULL)return;
	Student item = cur->item;
	if (item.compare3(Id))
	{
		duplicate = true; //the id have been exist
		return;
	}
	checkDuplicate(cur->left, Id, duplicate);
	checkDuplicate(cur->right, Id, duplicate);
}

bool readFile(const char* filename, BST* t1)
{
	char r[999]; 
	int count = 0; //count the number of student inserted
	cout << "Reading File..." << endl;
	ifstream in(filename);
	if (!in)
	{
		cout << "Unable to open this file!\n\n";
		return false;
	}
	else
	{
		int duplicate_count = 0; // to count number of duplicate result(s) found
		while (!in.eof())
		{
			Student* stuNode = new Student; // new memory space for student node
			if (!stuNode)
			{
				return false;
			}
			char Name[30];
			char Address[100];
			in >> r >> r >> r; // ignore "Student Id ="
			in >> stuNode->id;
			in >> r >> r;

			in >> Name; //read first name
			in.getline(r, 30); //read remaining name
			strcat(Name, r); // combine first name and remaining name to become a full name
			strcpy(stuNode->name, Name);
			in >> r >> r;
			in >> Address; //read first word of address
			in.getline(r, 100); // read the remaining address
			strcat(Address, r);
			strcpy(stuNode->address, Address);
			in >> r >> r;
			in >> stuNode->DOB;
			in >> r >> r >> r;
			in >> stuNode->phone_no;
			in >> r >> r;
			in >> stuNode->course;
			in >> r >> r;
			in >> stuNode->cgpa;

			//check duplicate before insert into BST
			bool duplicate = false;
			
			checkDuplicate(t1->root, stuNode->id, duplicate);
			if (!duplicate)
			{
				//if no existing record, then insert record
				t1->insert(*stuNode);
				count++;
			}
			else
			{
				duplicate_count++;
				cout << duplicate_count << " Duplicate result(s) found...unable insert from the file!" << endl;
				
			}
		}
		cout << endl;
		cout << count << " record of students have been successfully read.\n\n";
	}
	return true;
}

int menu()
{
	cout << "(1)" << " " << "Read data to BST\n";
	cout << "(2)" << " " << "Print deepest nodes\n";
	cout << "(3)" << " " << "Display student\n";
	cout << "(4)" << " " << "Clone subtree\n";
	cout << "(5)" << " " << "Print Level Nodes\n";
	cout << "(6)" << " " << "Print Path\n";
	cout << "(7)" << " " << "Exit\n\n";

	int selection;
	cout << "Selection: ";
	cin >> selection;
	system("cls");
	cout << endl;
	return selection;
}

